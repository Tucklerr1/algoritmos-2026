while True:
    valor = int(input("Digite o valor do saque: "))
    possivel = False
    for n100 in range(valor//100+1):
        for n50 in range(valor//50+1):
            for n20 in range(valor//20+1):
                if n100*100+n50*50+n20*20==valor:
                    possivel=True
                    break
            if possivel:
                break
        if possivel:
            break
    if possivel:
        print("Saque realizado com sucesso!")
        break
    else:
        print("Não é possível realizar este saque.")