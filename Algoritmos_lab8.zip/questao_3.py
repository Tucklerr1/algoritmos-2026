import random
secreto = random.randint(1, 10)
chances = 5
while chances > 0:
    palpite = int(input("Adivinhe o número (1 a 10): "))
    if palpite<1 or palpite>10:
        print("Número inválido. Digite um valor entre 1 e 10.")
        continue
    if palpite==secreto:
        print("Parabéns, você acertou")
        break
    chances-=1
    print(f"Errou, restam {chances} chances.")
if chances==0:
    print(f"Fim de jogo, O número era {secreto}.")