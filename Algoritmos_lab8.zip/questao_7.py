degrau=1
while True:
    print("\n=== JOGO DA ESCADA ===")
    print(f"Degrau atual: {degrau}")
    passos=int(input("Digite o número de passos (1-6) ou 0 para sair: "))
    if passos==0:
        print("Você desistiu do jogo.")
        break
    if passos<1 or passos>6:
        print("Valor inválido, tente novamente!")
        continue
    destino=degrau+passos
    if destino%3==0:
        destino-=1
        print(f"[Degrau: {degrau+passos} | Múltiplo de 3] Volte 1 degrau ")
    elif destino%5==0:
        destino+=1
        print(f"[Degrau: {degrau+passos} | Múltiplo de 5] Avance 1 degrau ")
    elif destino%7==0:
        destino+=4
        print(f"[Degrau: {degrau+passos} | Múltiplo de 7] Avance 4 degraus! ")
    elif destino%11==0:
        destino=1
        print(f"[Degrau: {degrau+passos} | Múltiplo de 11] Volte para o início ")
    degrau=destino
    if degrau>=100:
        print("Parabéns! Você venceu ")
        break