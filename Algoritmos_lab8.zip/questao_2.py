cont = 5
while cont > 0: 
    num = int(input("Digite um número inteiro: "))
    cont -= 1
    if num % 2 == 0: 
        continue
    print(f'{num} é um número ímpar')
#Quando digita um número par, o sistema continua repetindo até digitar um número ímpar.
#Quando digita um número ímpar, o sistema printa: "(X) é um número ímpar", e continua repetindo.