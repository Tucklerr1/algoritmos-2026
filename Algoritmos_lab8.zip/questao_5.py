total=0
while True:
    print("CARDÁPIO")
    print("1: Temaki - R$12,00")
    print("2: Sushi - R$6,50")
    print("3: Maki - R$10,00")
    print("4: Fechar a conta")
    opcao=int(input("Escolha uma opção: "))
    if opcao==1:
        total+=12
    elif opcao==2:
        total+=6.5
    elif opcao==3:
        total+=10
    elif opcao==4:
        print(f"\nTotal da conta: R${total:.2f}")
        break
    else:
        print("Opção inválida!")
        continue
    print(f"Total parcial: R${total:.2f}")