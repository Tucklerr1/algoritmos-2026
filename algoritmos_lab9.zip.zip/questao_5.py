n=int(input('Quantos valores deseja digitar? '))
soma=0
quant=0
while quant<n:
    valor=int(input('Digite um valor: '))
    soma+=valor
    quant+=1
    media=soma/quant
    print('Soma: ', soma)
    print('Quantidade: ', quant)
    print('Média', media)