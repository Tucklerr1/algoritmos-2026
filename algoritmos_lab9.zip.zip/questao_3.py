#==========
#A)
#==========
i=0
while i<10:
    print(i)
    i+=1
#i: 0,1,2,3,4,5,6,7,8,9     repetições: 10



#==========
#B)
#==========
x=2
while x<=32:
    print(x)
    x=x*2
#x: 2,4,8,16,32     repetições: 5



#==========
#C)
#==========
n=100
cont=100
while n>1:
    print(n, cont)
    n=n//2
    cont+=1
#n: 100,50,25,12,6,3     repetições: 6



#==========
#D)
#==========
a=1
while True:
    print(a)
    a=a+3
    if a>10:
        break
#a: 1,4,7,10     repetições: 4



#==========
#E)
#==========
soma=10
i=0
while i<10:
    print(i, soma)
    i+=1
    if i==5:
        break
    soma+=i
#i: 0,1,2,3,4     soma:10,11,13,16,20 (70)     repetições: 5



#==========
#F)
#==========
soma=0
i=0
while i<10:
    print(i, soma)
    i +=1
    if i%2==0:
        continue
    soma+=i
#i: 0,1,2,3,4,5,6,7,8,9     soma: 0,1,4,4,9,9,16,16,25 (89)     repetições:10



#==========
#G)
#==========
soma=10
i=0
while i<10:
    print(i, soma)
    i+=1
    if i==3:
        continue
    if i==7:
        break
    soma+=i
#i: 0,1,2,3,4,5,6     soma: 10,11,13,13,17,22,28 (132)     repetições: 7