v=[7,42,21,64,14,2,73,33,17,1]
soma_impares=0
impares=""
for x in v:
    if x%2!=0:
        soma_impares+=x
        impares=(f"{impares}, {x}")
print(f"A soma de {impares} é {soma_impares}")