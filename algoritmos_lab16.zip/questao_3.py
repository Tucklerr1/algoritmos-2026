v=[7,42,21,64,14,2,73,33,17,1]
mult=1
for x in v:
    if x>=20 and x<=60:
        mult*=x
print(f"A multiplicação dos elementos entre 20 e 60 é {mult}.")