v=[7,42,21,64,14,2,73,33,17,1]
soma_pares=0
soma_impares=0
for x in v:
    if x%2==0:
        soma_pares+=x
    else:
        soma_impares+=x
print(f"A soma dos números pares é {soma_pares}. A soma dos números ímpares é {soma_impares}.")