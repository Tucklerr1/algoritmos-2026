v=[7,42,21,64,14,2,73,33,17,1]
media=0
soma=0
for x in v:
    soma+=x
media=soma/10
print(f"A média de v é {media}.")