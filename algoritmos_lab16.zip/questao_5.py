v=[7, 42, 21, 64, 14, 2, 73, 33, 17, 1]
n=int(input("Digite um número: "))

posicao=-1
cont=0
for x in v:
    if x==n:
        posicao=cont
        break
    cont+=1
if posicao != -1:
    print(f"Número encontrado na posição {posicao}")
else:
    print("Número não encontrado")
