jogos=int(input("Quantidade de jogos: "))
vit=0
emp=0
der=0
pontos=0
for i in range(jogos):
    gols_galao=int(input("Gols do Galo: "))
    gols_fregues=int(input("Gols do adversário: "))

    if gols_galao>gols_fregues:
        vit+=1
        pontos+=3
    elif gols_galao==gols_fregues:
        emp+=1
        pontos+=1
    else:
        der+=1
print(f"Vitórias: {vit}")
print(f"Empates: {emp}")
print(f"Derrotas: {der}")
print(f"Pontuação: {pontos}")

#A derrota é impossível para o maior de Minas