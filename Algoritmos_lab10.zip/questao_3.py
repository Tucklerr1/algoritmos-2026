soma=0
for i in range(10):
    num=int(input("Digite um número inteiro positivo: "))
    soma+=num
print(f"Soma={soma}")
