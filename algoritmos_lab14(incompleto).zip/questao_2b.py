def ola(nome, genero):
    if genero=='masculino':
        return f'Olá, {nome}, Bem-Vindo!'
    if genero=='feminino':
        return f'Olá, {nome}, Bem-Vinda!'
    else:
        return f'Olá, {nome}, Boas-Vindas!'

txt1=ola('Leo','masculino')
print(txt1)
txt2=ola("Mila", "feminino")
print(txt2)
txt3=ola("Alan", "67")
print(txt3)