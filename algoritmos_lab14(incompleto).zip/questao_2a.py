def ola(nome):
    return f'Olá, {nome}'
txt = ola('Maria!')
print(txt)
