N = int(input("Quantos números quer digitar?"))
contador = 1
impares = 0

while contador <= N:
    num = int(input("Digite um número: "))
    if num % 2 != 0:
        impares += 1
    #o contador não foi incrementado
    contador+=1
print(f"Quantidade de ímpares: {impares}")
#não sei direito como explicar, mas entre 1 e n não tem os ímpares