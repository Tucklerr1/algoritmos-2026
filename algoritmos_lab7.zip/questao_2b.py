#não está pedindo 10 variáveis, está pedindo pra somar até chegar a 10
soma = 0
num1=int(input("Digite um número para somar: "))
num2=int(input("Digite um número para somar: "))
num3=int(input("Digite um número para somar: "))
num4=int(input("Digite um número para somar: "))
num5=int(input("Digite um número para somar: "))
num6=int(input("Digite um número para somar: "))
num7=int(input("Digite um número para somar: "))
num8=int(input("Digite um número para somar: "))
num9=int(input("Digite um número para somar: "))
num10=int(input("Digite um número para somar: "))
soma=num1+num2+num3+num4+num5+num6+num7+num8+num9+num10
print(soma)