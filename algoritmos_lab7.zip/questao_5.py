import random
chances=10
numero_secreto=random.randint(1, 1000)
while chances > 0: 
    num = int(input(f"Qual o número secreto? Você tem {chances} chances"))
    chances -= 1
    if num == numero_secreto:
        print("Você acertou o número, toma aqui uma batata 🥔")
        break
    if num > numero_secreto:
        print('menor')
    if num < numero_secreto:
        print('maior')