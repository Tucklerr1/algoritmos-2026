N = int(input("Quantos números quer digitar?"))
maior = float('-inf')
contador = 0
soma = 0
while contador <= N:
    while soma <= 10: 
        num = int(input("Digite um número: "))
        if num > maior:
            maior = num
        print('O maior número é', maior)