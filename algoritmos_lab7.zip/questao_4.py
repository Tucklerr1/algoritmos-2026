import random
chances=5
numero_secreto=random.randint(1, 10)
while chances > 0: 
    num = int(input(f"Qual o número secreto? Você tem {chances} chances"))
    chances -= 1
    if num == numero_secreto:
        print("Você acertou o número, toma aqui uma batata 🥔")
        break