valor_hora=float(input("Quanto você recebe por hora? R$"))
horas_semana=float(input("Quantas horas trabalha por semana? "))
salario_bruto=valor_hora*horas_semana
print(f"Seu salário bruto é de R${salario_bruto:.2f}")
salario_liq=salario_bruto-(salario_bruto * 0.10)-(salario_bruto * 0.05)
print(f"Seu salário líquido é de R${salario_liq:.2f}")