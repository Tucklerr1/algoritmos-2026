meses=int(input("Digite o número de meses: "))
seguidores=100*(2**meses)
print(f"Após {meses} meses, a pessoa terá {seguidores} seguidores.")