distancia=42
tempo=4
velmedia=distancia//tempo
print(f"Você precisa correr a {velmedia} km/h para completar a São Silvestre em 4 horas.")