km_litro=float(input("Quantos km seu carro faz por litro? "))
dist=float(input("Quantos km pretende viajar? "))
preco_combustivel=float(input("Qual o valor do combustível? R$"))
pedagios=float(input("Quanto será gasto com pedágios? R$"))
pessoas=int(input("Quantas pessoas vão dividir a conta? "))

litros_necessarios=dist/km_litro
gasto_comb=litros_necessarios*preco_combustivel

gasto_total=gasto_comb+pedagios
gasto_porpessoa=gasto_total/pessoas

print(f"Cada pessoa deverá gastar R${gasto_porpessoa:.2f}")