from funcoes import temp
x=temp(67)
print(x)