from funcoes import area
x=area(3)
print(x)