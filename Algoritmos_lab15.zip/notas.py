from funcoes import notas
x=notas(42, 67, 13)
print(x)