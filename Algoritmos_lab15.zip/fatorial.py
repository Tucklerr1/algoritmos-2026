from funcoes import fatorial
x=fatorial(67)
print(x)
