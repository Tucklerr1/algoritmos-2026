def fatorial(n):
    x=1
    for i in range(1,n+1):
        x=x*i
    return x

def reajuste(sal_base, aumento):
    sal_base=(sal_base)+sal_base/100*aumento
    return sal_base, aumento

def temp(c):
    c=c*1
    f=c*1.8+32
    return c, f
    
def notas(aluno1, aluno2, aluno3):
    media=(aluno1+aluno2+aluno3)/3
    return media
    
def area(r):
    r=(r**2)*3.14
    return r