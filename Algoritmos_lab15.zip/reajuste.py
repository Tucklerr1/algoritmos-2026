from funcoes import reajuste
x=reajuste(8000, 50)
print(x)