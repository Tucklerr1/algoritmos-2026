from funcoes import dados
from funcoes import media
from funcoes import acimamedia
from funcoes import separar
from funcoes import estatisticas
from funcoes import busca_maior
from funcoes import vetconceitos

vetnomes,vetnotas=dados()
medturma=media(vetnotas)
print("Média da turma: ",medturma)

quant_acima=acimamedia(vetnotas,medturma)
print("Quantidade de alunos acima ou igual à média: ",quant_acima)

pares,impares=separar(vetnotas)
print("Notas em posições pares: ",pares)
print("Notas em posições ímpares: ",impares)

p_aprov,p_rec,p_reprov=estatisticas(vetnotas)
print("Percentual de aprovados: ",p_aprov,"%")
print("Percentual de recuperação :",p_rec,"%")
print("Percentual de reprovados :",p_reprov,"%")

nota_max,aluno_nota_max=busca_maior(vetnomes,vetnotas)
print("Maior nota da turma: ",nota_max)
print("Aluno que recebeu a maior nota: ",aluno_nota_max)

vetor_conceitos=vetconceitos(vetnotas)
print("Vetor de conceitos: ",vetor_conceitos)
