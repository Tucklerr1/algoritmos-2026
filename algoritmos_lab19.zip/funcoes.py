def dados():
    nomes=[""]*10
    notas=[0]*10
    for i in range(10):
        nomes[i]=input("Digite o nome: ")
        notas[i]=float(input("Digite a nota: "))
    return nomes,notas
    
def media(notas):
    soma=0
    for i in range(10):
        soma+=notas[i]
    media=soma/10
    return media

def acimamedia(notas,media):
    cont=0
    for i in range(10):
        if notas[i]>=media:
            cont+=1
    return cont

def separar(notas):
    notas_pares=[]
    notas_impares=[]
    for i in range(10):
        if i%2==0:
            notas_pares.append(notas[i])
        else:
            notas_impares.append(notas[i])
    return notas_pares,notas_impares

def estatisticas(notas):
    aprovados=0
    rec=0
    reprovados=0
    for i in range(10):
        if notas[i]>=70:
            aprovados+=1
        elif notas[i]>=50:
            rec+=1
        else:
            reprovados+=1
    pct_aprovados=(aprovados/10)*100
    pct_rec=(rec/10)*100
    pct_reprovados=(reprovados/10)*100
    return pct_aprovados,pct_rec,pct_reprovados
    
def busca_maior(nomes,notas):
    maior_nota=notas[0]
    posicao_maior=0
    for i in range(1,10):
        if notas[i]>maior_nota:
            maior_nota=notas[i]
            posicao_maior=i
    aluno_maior=nomes[posicao_maior]
    return maior_nota,aluno_maior

def vetconceitos(notas):
    conceitos=[""]*10
    for i in range(10):
        if notas[i]>=90:
            conceitos[i]="A"
        elif notas[i]>=70:
            conceitos[i]="B"
        elif notas[i]>=50:
            conceitos[i]="C"
        else:
            conceitos[i]="D"
    return conceitos
