def buscamaior(vet):
    maior=vet[0]
    for i in range(0, 10):
        if vet[i]>maior:
            maior=vet[i]
    return maior