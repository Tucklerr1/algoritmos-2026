from funcao import buscamaior
vet = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
for x in range(0, 10):
    vet[x] = int(input(f"Digite o {x+1}º valor: "))
maior = buscamaior(vet)
print(f"O maior valor do vetor é {maior}")
