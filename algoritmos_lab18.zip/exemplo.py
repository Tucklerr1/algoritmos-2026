def buscamaior(vet):
    maior=vet[0]
    for i in range(0,10):
        if vet[i]>maior:
            maior=vet[i]
    return maior

vet=[0,0,0,0,0,0,0,0,0,0]
for x in range (0,10):
    vet[x]=int(input(f"Digite o {x+1}º valor: "))
print(f"O maior valor do vetor é {buscamaior(vet)}")

#Exemplo que a professora passou no quadro