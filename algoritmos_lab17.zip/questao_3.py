from funcoes import maior, menor
vet=[14,2,63,27,3,49,52,10,77,1]
nmaior=maior(vet)
nmenor=menor(vet)
print(f"O maior número é {nmaior} e o menor é {nmenor}")