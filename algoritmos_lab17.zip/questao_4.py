from funcoes import somar
vet=[14,2,63,27,3,49,52,10,77,1]
soma=somar(vet)
print(f"A soma das posições de todos os elementos pares é {soma}")