def buscar(n, vet):
    for i in range(0,9):
        if n==vet[i]:
            return f'Número está na posição {i}.'
    return 'Número não encontrado.'

def achar_intervalo(n1, n2, vet):
    somar=0
    for i in range(n1,n2+1):
        somar+=vet[i]
    return somar

def maior(vet):
    maior=float('-inf')
    for i in range(0,9):
        if vet[i]>maior:
            maior=vet[i]
    return maior

def menor(vet):
    menor = float('inf')
    for i in range(0,9):
        if vet[i] < menor:
            menor = vet[i]
    return menor

def somar(vet):
    soma=0
    for i in range(0,9):
        if vet[i]%2==0:
            soma+=vet[i]
    return soma