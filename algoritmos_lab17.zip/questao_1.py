from funcoes import buscar
vet=[14,2,63,27,3,49,52,10,77,1]
n=int(input("Digite um número: "))
verificado=buscar(n, vet)
print(verificado)