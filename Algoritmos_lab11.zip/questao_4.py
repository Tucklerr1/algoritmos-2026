import random
pontos1=0
pontos2=0
rodada=1
while pontos1<50 and pontos2<50:
    print("RODADA", rodada, "")
    palpite1=int(input("Jogador 1: "))
    palpite2=int(input("Jogador 2: "))
    dado1=random.randint(1, 6)
    dado2=random.randint(1, 6)
    soma=dado1 + dado2
    print("Dado 1:", dado1)
    print("Dado 2:", dado2)
    print("Soma:", soma)
    dif1=soma-palpite1
    if dif1<0:
        dif1=dif1*(-1)
    dif2=soma-palpite2
    if dif2<0:
        dif2=dif2*(-1)
    if dif1<dif2:
        pontos1=pontos1+5
        print("Jogador 1 ganha 5 pontos!")
    elif dif2<dif1:
        pontos2=pontos2+5
        print("Jogador 2 ganha 5 pontos!")
    else:
        pontos1=pontos1+2
        pontos2=pontos2+2
        print("Empate! Cada um ganha 2 pontos!")
    print("Placar:", pontos1, "x", pontos2)
    rodada=rodada+1
if pontos1>=50:
    print("Jogador 1 venceu!")
else:
    print("Jogador 2 venceu!")