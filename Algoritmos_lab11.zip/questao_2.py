while True:
    resposta=input("Você quer saber como manter uma pessoa ingênua ocupada por horas? S/N\n> ")
    if resposta=="s" or resposta=="S" or resposta=="sim" or resposta=="SIM":
        continue
    elif resposta=="n" or resposta=="N" or resposta=="não" or resposta=="NÃO":
        print("Obrigada. Tenha um bom dia!")
        break
    else:
        print("Resposta inválida.")