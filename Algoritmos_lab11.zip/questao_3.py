import random
while True:
    resposta = input("Deseja fazer uma pergunta? (s/n) ")
    if resposta=="n" or resposta=="N":
        print("Até logo")
        break
    pergunta=input("Faça sua pergunta: ")
    print("Deixe-me pensar...")
    print("Estou quase...")
    print("A resposta é...")
    numero=random.randint(1, 10)
    if numero<=5:
        print("SIM")
    else:
        print("NÃO")