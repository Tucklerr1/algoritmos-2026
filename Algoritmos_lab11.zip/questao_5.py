import random
a=random.randint(0, 9)
b=random.randint(0, 9)
c=random.randint(0, 9)
secreto=[str(a), str(b), str(c)]
for tentativa in range(10):
    palpite=input("Digite um número de 3 dígitos: ")
    resposta=""
    for i in range(3):
        if palpite[i]==secreto[i]:
            resposta+="+"
        elif palpite[i] in secreto:
            resposta+="!"
        else:
            resposta+="_"
    print(resposta)
    if resposta=="+++":
        print("Você acertou"")
        break
if resposta!="+++":
    print("Fim de jogo")
    print("Número secreto:", secreto[0] + secreto[1] + secreto[2])